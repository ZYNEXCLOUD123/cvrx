#!/bin/bash

# ==============================================================================
# CVRX Panel - Start with Auto-Update Check on Restart
# ==============================================================================

# Locate panel directory safely
if [ -n "$PANEL_ROOT" ] && [ -d "$PANEL_ROOT" ]; then
    PANEL_DIR="$PANEL_ROOT"
elif [ -f "package.json" ] && grep -q '"name": "cvrx-panel"' "package.json" 2>/dev/null; then
    PANEL_DIR="$(pwd)"
elif [ -f "$(dirname "$0")/../package.json" ]; then
    PANEL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
elif [ -d "/workspace/CVRX" ]; then
    PANEL_DIR="/workspace/CVRX"
elif [ -d "/workspace" ] && [ -f "/workspace/package.json" ]; then
    PANEL_DIR="/workspace"
elif [ -d "/app" ] && [ -f "/app/package.json" ]; then
    PANEL_DIR="/app"
elif [ -d "$HOME/CVRX" ]; then
    PANEL_DIR="$HOME/CVRX"
elif [ -d "/root/CVRX" ]; then
    PANEL_DIR="/root/CVRX"
else
    PANEL_DIR="$(pwd)"
fi

cd "$PANEL_DIR" || exit 1

echo "[CVRX Panel] Working Directory: $(pwd)"
echo "[CVRX Panel] Checking for updates from repository on restart..."

if command -v git &> /dev/null && [ -d ".git" ]; then
    # Fetch latest remote changes quietly
    git fetch origin main 2>/dev/null || git fetch origin master 2>/dev/null || true
    
    LOCAL_COMMIT=$(git rev-parse HEAD 2>/dev/null || echo "")
    REMOTE_COMMIT=$(git rev-parse @{u} 2>/dev/null || echo "")

    if [ -n "$LOCAL_COMMIT" ] && [ -n "$REMOTE_COMMIT" ] && [ "$LOCAL_COMMIT" != "$REMOTE_COMMIT" ]; then
        echo "[CVRX Panel] Updates detected ($LOCAL_COMMIT -> $REMOTE_COMMIT)! Pulling changes..."
        git pull --ff-only origin main 2>/dev/null || git pull --ff-only origin master 2>/dev/null || git pull || true
        
        echo "[CVRX Panel] Installing updated dependencies..."
        npm install --no-audit --no-fund --quiet || true
        
        echo "[CVRX Panel] Compiling production build..."
        npm run build || true
        echo "[CVRX Panel] Update successfully applied!"
    else
        echo "[CVRX Panel] Panel is up-to-date (commit: ${LOCAL_COMMIT:0:7})."
    fi
else
    echo "[CVRX Panel] Git repository not detected or git command unavailable, skipping auto-pull."
fi

# Ensure dist exists
if [ ! -f "dist/server.cjs" ]; then
    echo "[CVRX Panel] Compiling initial build..."
    npm run build
fi

echo "[CVRX Panel] Launching CVRX Server Management Panel in production mode..."
export NODE_ENV=production
exec node dist/server.cjs
